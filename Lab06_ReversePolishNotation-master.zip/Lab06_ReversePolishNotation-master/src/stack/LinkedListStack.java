package stack;

public class LinkedListStack<E> implements Stack<E> {

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public E top() throws Underflow {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void push(E element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public E pop() throws Underflow {
		// TODO Auto-generated method stub
		return null;
		
	}

}
