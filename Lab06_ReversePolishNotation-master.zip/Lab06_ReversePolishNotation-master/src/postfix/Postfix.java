package postfix;

public class Postfix {

	public String infixToPostfix(String infix) {
		// TODO Auto-generated method stub
		return null;
	}

	public double evaluate(String postfix) {
		// TODO Auto-generated method stub
		return 0;
	}

}
