# Lab06_ReversePolishNotation

This is a Scaffold for working on [this exercise](http://bkleinen.github.io/info2/labs/lab-06.html).

An IntelliJ Idea Project using JDK 1.8.

Make sure you have junit-4.12.jar and hamcrest-core-1.3.jar added to your dependencies. See [IntelliJ documentation](https://www.jetbrains.com/help/idea/configuring-testing-libraries.html) for more info.
